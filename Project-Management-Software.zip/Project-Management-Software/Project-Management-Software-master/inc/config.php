<?php

if (!defined('APPLICATION_LOADED') || !APPLICATION_LOADED) {
    die('No direct script access.');
}

mb_internal_encoding("UTF-8");

$CONFIG = array();

$CONFIG['PERMISSIONS'] = array(
    'CREATE_PROJECT' => 1,
    'SETTINGS_PAGE' => 2,
    'TICKETS' => array(
        'ADD_EDIT_MINE_TICKETS' => 3, 
        'ADD_EDIT_ALL_TICKETS' => 4 
    ),
    'WIKI' => array(
        'ADD_NEW_SPACES' => 5,
        'ADD_NEW_PAGES' => 6,
        'EDIT_OTHER_PAGES' => 7, 
        'DELETE_PAGES' => 8,
        'MOVE_PAGES' => 9
    )
);

$CONFIG['DEFAULT_USER_TYPES'] = array(
    'Admin' => '1,2,3,4,5,6,7,8,9',
    'Super User' => '3,4,5,6,7,8,9',
    'User' => '3, 6',
    'Watcher' => ''
);


$CONFIG['USERNAMEREGEX'] = '/^[a-zа-яA-ZА-Я0-9]+$/'; 
$CONFIG['FULLNAMEREGEX'] = '/^[a-zа-яA-ZА-Я\s]+$/'; 
$CONFIG['EMAILREGEX'] = '/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/'; 
$CONFIG['IMAGESUSERSUPLOADDIR'] = 'attachments/' . ACCOUNT_DOMAIN . '/users_profile/'; 
$CONFIG['IMAGELOGINUPLOADDIR'] = 'attachments/' . ACCOUNT_DOMAIN . '/login_image/'; 
$CONFIG['ATTACHMENTS_DIR'] = 'attachments/' . ACCOUNT_DOMAIN . '/imap/'; 
$CONFIG['DEFAULTUSERIMAGE'] = 'default/male.jpg'; 
$CONFIG['IMAGESSPACESUPLOADDIR'] = 'attachments/' . ACCOUNT_DOMAIN . '/space_logos/'; 
$CONFIG['DEFAULTSPACEIMAGE'] = 'default/space-logo.png'; 
$CONFIG['SPACEKEYREGEX'] = '/^[a-zA-Zа-яА-Я0-9_]+$/'; 
$CONFIG['WIKI_PAGES_NAMES'] = '/^[a-zA-Zа-яА-Я0-9_-]+$/';


$CONFIG['ISSUE_LINKS'] = array(
    'relates_to' => 'relates_to',
    'is_duplicated_by' => 'duplicates',
    'duplicates' => 'is_duplicated_by',
    'is_blocked_by' => 'blocks',
    'blocks' => 'is_blocked_by'
);
?>