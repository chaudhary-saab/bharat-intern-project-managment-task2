<?php

if (!defined('APPLICATION_LOADED') || !APPLICATION_LOADED) {
    die('No direct script access.');
}


define('HOST', 'localhost');
define('USER', 'root');
define('PASS', 'toor');
define('DATABASE', 'issue-tracking-system');
