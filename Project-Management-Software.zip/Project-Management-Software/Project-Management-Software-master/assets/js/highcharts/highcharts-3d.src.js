



(function (factory) {
    if (typeof module === 'object' && module.exports) {
        module.exports = factory;
    } else {
        factory(Highcharts);
    }
}(function (Highcharts) {

    var each = Highcharts.each,
        extend = Highcharts.extend,
        inArray = Highcharts.inArray,
        merge = Highcharts.merge,
        pick = Highcharts.pick,
        wrap = Highcharts.wrap;
    
    var PI = Math.PI,
        deg2rad = (PI / 180), 
        sin = Math.sin,
        cos = Math.cos,
        round = Math.round;

    
    function perspective(points, chart, insidePlotArea) {
        var options3d = chart.options.chart.options3d,
            inverted = false,
            origin;

        if (insidePlotArea) {
            inverted = chart.inverted;
            origin = {
                x: chart.plotWidth / 2,
                y: chart.plotHeight / 2,
                z: options3d.depth / 2,
                vd: pick(options3d.depth, 1) * pick(options3d.viewDistance, 0)
            };
        } else {
            origin = {
                x: chart.plotLeft + (chart.plotWidth / 2),
                y: chart.plotTop + (chart.plotHeight / 2),
                z: options3d.depth / 2,
                vd: pick(options3d.depth, 1) * pick(options3d.viewDistance, 0)
            };
        }

        var result = [],
            xe = origin.x,
            ye = origin.y,
            ze = origin.z,
            vd = origin.vd,
            angle1 = deg2rad * (inverted ?  options3d.beta  : -options3d.beta),
            angle2 = deg2rad * (inverted ? -options3d.alpha :  options3d.alpha),
            s1 = sin(angle1),
            c1 = cos(angle1),
            s2 = sin(angle2),
            c2 = cos(angle2);

        var x, y, z, px, py, pz;

        
        each(points, function (point) {
            x = (inverted ? point.y : point.x) - xe;
            y = (inverted ? point.x : point.y) - ye;
            z = (point.z || 0) - ze;

            
            px = c1 * x - s1 * z;
            py = -s1 * s2 * x + c2 * y - c1 * s2 * z;
            pz = s1 * c2 * x + s2 * y + c1 * c2 * z;


            
            if ((vd > 0) && (vd < Number.POSITIVE_INFINITY)) {
                px = px * (vd / (pz + ze + vd));
                py = py * (vd / (pz + ze + vd));
            }

            
            px = px + xe;
            py = py + ye;
            pz = pz + ze;

            result.push({
                x: (inverted ? py : px),
                y: (inverted ? px : py),
                z: pz
            });
        });
        return result;
    }
    
    Highcharts.perspective = perspective;
   

    var dFactor = (4 * (Math.sqrt(2) - 1) / 3) / (PI / 2);

    function defined(obj) {
        return obj !== undefined && obj !== null;
    }

    
    function shapeArea(vertexes) {
        var area = 0,
            i,
            j;
        for (i = 0; i < vertexes.length; i++) {
            j = (i + 1) % vertexes.length;
            area += vertexes[i].x * vertexes[j].y - vertexes[j].x * vertexes[i].y;
        }
        return area / 2;
    }

    function averageZ(vertexes) {
        var z = 0,
            i;
        for (i = 0; i < vertexes.length; i++) {
            z += vertexes[i].z;
        }
        return vertexes.length ? z / vertexes.length : 0;
    }

   
    function curveTo(cx, cy, rx, ry, start, end, dx, dy) {
        var result = [];
        if ((end > start) && (end - start > PI / 2 + 0.0001)) {
            result = result.concat(curveTo(cx, cy, rx, ry, start, start + (PI / 2), dx, dy));
            result = result.concat(curveTo(cx, cy, rx, ry, start + (PI / 2), end, dx, dy));
        } else if ((end < start) && (start - end > PI / 2 + 0.0001)) {
            result = result.concat(curveTo(cx, cy, rx, ry, start, start - (PI / 2), dx, dy));
            result = result.concat(curveTo(cx, cy, rx, ry, start - (PI / 2), end, dx, dy));
        } else {
            var arcAngle = end - start;
            result = [
                'C',
                cx + (rx * cos(start)) - ((rx * dFactor * arcAngle) * sin(start)) + dx,
                cy + (ry * sin(start)) + ((ry * dFactor * arcAngle) * cos(start)) + dy,
                cx + (rx * cos(end)) + ((rx * dFactor * arcAngle) * sin(end)) + dx,
                cy + (ry * sin(end)) - ((ry * dFactor * arcAngle) * cos(end)) + dy,

                cx + (rx * cos(end)) + dx,
                cy + (ry * sin(end)) + dy
            ];
        }
        return result;
    }

    Highcharts.SVGRenderer.prototype.toLinePath = function (points, closed) {
        var result = [];

        
        Highcharts.each(points, function (point) {
            result.push('L', point.x, point.y);
        });

        if (points.length) {
           
            result[0] = 'M';

            
            if (closed) {
                result.push('Z');
            }
        }

        return result;
    };

    
    Highcharts.SVGRenderer.prototype.cuboid = function (shapeArgs) {

        var result = this.g(),
            paths = this.cuboidPath(shapeArgs);

        
        result.front = this.path(paths[0]).attr({ zIndex: paths[3], 'stroke-linejoin': 'round' }).add(result);
        result.top = this.path(paths[1]).attr({ zIndex: paths[4], 'stroke-linejoin': 'round' }).add(result);
        result.side = this.path(paths[2]).attr({ zIndex: paths[5], 'stroke-linejoin': 'round' }).add(result);

        
        result.fillSetter = function (color) {
            var c0 = color,
                c1 = Highcharts.Color(color).brighten(0.1).get(),
                c2 = Highcharts.Color(color).brighten(-0.1).get();

            this.front.attr({ fill: c0 });
            this.top.attr({ fill: c1 });
            this.side.attr({ fill: c2 });

            this.color = color;
            return this;
        };

        
        result.opacitySetter = function (opacity) {
            this.front.attr({ opacity: opacity });
            this.top.attr({ opacity: opacity });
            this.side.attr({ opacity: opacity });
            return this;
        };

        result.attr = function (args) {
            if (args.shapeArgs || defined(args.x)) {
                var shapeArgs = args.shapeArgs || args;
                var paths = this.renderer.cuboidPath(shapeArgs);
                this.front.attr({ d: paths[0], zIndex: paths[3] });
                this.top.attr({ d: paths[1], zIndex: paths[4] });
                this.side.attr({ d: paths[2], zIndex: paths[5] });
            } else {
                return Highcharts.SVGElement.prototype.attr.call(this, args); 
            }

            return this;
        };

        result.animate = function (args, duration, complete) {
            if (defined(args.x) && defined(args.y)) {
                var paths = this.renderer.cuboidPath(args);
                this.front.attr({ zIndex: paths[3] }).animate({ d: paths[0] }, duration, complete);
                this.top.attr({ zIndex: paths[4] }).animate({ d: paths[1] }, duration, complete);
                this.side.attr({ zIndex: paths[5] }).animate({ d: paths[2] }, duration, complete);
                this.attr({
                    zIndex: -paths[6] // #4774
                });
            } else if (args.opacity) {
                this.front.animate(args, duration, complete);
                this.top.animate(args, duration, complete);
                this.side.animate(args, duration, complete);
            } else {
                Highcharts.SVGElement.prototype.animate.call(this, args, duration, complete);
            }
            return this;
        };

        
        result.destroy = function () {
            this.front.destroy();
            this.top.destroy();
            this.side.destroy();

            return null;
        };

        
        result.attr({ zIndex: -paths[6] });

        return result;
    };

    
    Highcharts.SVGRenderer.prototype.cuboidPath = function (shapeArgs) {
        var x = shapeArgs.x,
            y = shapeArgs.y,
            z = shapeArgs.z,
            h = shapeArgs.height,
            w = shapeArgs.width,
            d = shapeArgs.depth,
            chart = Highcharts.charts[this.chartIndex],
            map = Highcharts.map;

        
        var pArr = [
            { x: x, y: y, z: z },
            { x: x + w, y: y, z: z },
            { x: x + w, y: y + h, z: z },
            { x: x, y: y + h, z: z },
            { x: x, y: y + h, z: z + d },
            { x: x + w, y: y + h, z: z + d },
            { x: x + w, y: y, z: z + d },
            { x: x, y: y, z: z + d }
        ];

        
        pArr = perspective(pArr, chart, shapeArgs.insidePlotArea);

        
        function mapPath(i) {
            return pArr[i];
        }
        var pickShape = function (path1, path2) {
            var ret = [];
            path1 = map(path1, mapPath);
            path2 = map(path2, mapPath);
            if (shapeArea(path1) < 0) {
                ret = path1;
            } else if (shapeArea(path2) < 0) {
                ret = path2;
            }
            return ret;
        };

       
        var front = [3, 2, 1, 0];
        var back = [7, 6, 5, 4];
        var path1 = pickShape(front, back);

        
        var top = [1, 6, 7, 0];
        var bottom = [4, 5, 2, 3];
        var path2 = pickShape(top, bottom);

        
        var right = [1, 2, 5, 6];
        var left = [0, 7, 4, 3];
        var path3 = pickShape(right, left);

        return [this.toLinePath(path1, true), this.toLinePath(path2, true), this.toLinePath(path3, true), averageZ(path1), averageZ(path2), averageZ(path3), averageZ(map(bottom, mapPath)) * 9e9]; // #4774
    };

    
    Highcharts.SVGRenderer.prototype.arc3d = function (attribs) {

        var wrapper = this.g(),
            renderer = wrapper.renderer,
            customAttribs = ['x', 'y', 'r', 'innerR', 'start', 'end'];

        
        function suckOutCustom(params) {
            var hasCA = false,
                ca = {};
            for (var key in params) {
                if (inArray(key, customAttribs) !== -1) {
                    ca[key] = params[key];
                    delete params[key];
                    hasCA = true;
                }
            }
            return hasCA ? ca : false;
        }

        attribs = merge(attribs);

        attribs.alpha *= deg2rad;
        attribs.beta *= deg2rad;
    
        
        wrapper.top = renderer.path();
        wrapper.side1 = renderer.path();
        wrapper.side2 = renderer.path();
        wrapper.inn = renderer.path();
        wrapper.out = renderer.path();

        
        wrapper.onAdd = function () {
            var parent = wrapper.parentGroup;
            wrapper.top.add(wrapper);
            wrapper.out.add(parent);
            wrapper.inn.add(parent);
            wrapper.side1.add(parent);
            wrapper.side2.add(parent);
        };

      
        wrapper.setPaths = function (attribs) {

            var paths = wrapper.renderer.arc3dPath(attribs),
                zIndex = paths.zTop * 100;

            wrapper.attribs = attribs;

            wrapper.top.attr({ d: paths.top, zIndex: paths.zTop });
            wrapper.inn.attr({ d: paths.inn, zIndex: paths.zInn });
            wrapper.out.attr({ d: paths.out, zIndex: paths.zOut });
            wrapper.side1.attr({ d: paths.side1, zIndex: paths.zSide1 });
            wrapper.side2.attr({ d: paths.side2, zIndex: paths.zSide2 });


           
            wrapper.zIndex = zIndex;
            wrapper.attr({ zIndex: zIndex });

            
            if (attribs.center) {
                wrapper.top.setRadialReference(attribs.center);
                delete attribs.center;
            }
        };
        wrapper.setPaths(attribs);

        
        wrapper.fillSetter = function (value) {
            var darker = Highcharts.Color(value).brighten(-0.1).get();
        
            this.fill = value;

            this.side1.attr({ fill: darker });
            this.side2.attr({ fill: darker });
            this.inn.attr({ fill: darker });
            this.out.attr({ fill: darker });
            this.top.attr({ fill: value });
            return this;
        };

        
        each(['opacity', 'translateX', 'translateY', 'visibility'], function (setter) {
            wrapper[setter + 'Setter'] = function (value, key) {
                wrapper[key] = value;
                each(['out', 'inn', 'side1', 'side2', 'top'], function (el) {
                    wrapper[el].attr(key, value);
                });
            };
        });

       
        wrap(wrapper, 'attr', function (proceed, params, val) {
            var ca;
            if (typeof params === 'object') {
                ca = suckOutCustom(params);
                if (ca) {
                    extend(wrapper.attribs, ca);
                    wrapper.setPaths(wrapper.attribs);
                }
            }
            return proceed.call(this, params, val);
        });

       
        wrap(wrapper, 'animate', function (proceed, params, animation, complete) {
            var ca,
                from = this.attribs,
                to;

            delete params.center;
            delete params.z;
            delete params.depth;
            delete params.alpha;
            delete params.beta;

            animation = pick(animation, this.renderer.globalAnimation);
        
            if (animation) {
                if (typeof animation !== 'object') {
                    animation = {};
                }
            
                params = merge(params); 
                ca = suckOutCustom(params);
            
                if (ca) {
                    to = ca;
                    animation.step = function (a, fx) {
                        function interpolate(key) {
                            return from[key] + (pick(to[key], from[key]) - from[key]) * fx.pos;
                        }
                        fx.elem.setPaths(merge(from, {
                            x: interpolate('x'),
                            y: interpolate('y'),
                            r: interpolate('r'),
                            innerR: interpolate('innerR'),
                            start: interpolate('start'),
                            end: interpolate('end')
                        }));
                    };
                }
            }
            return proceed.call(this, params, animation, complete);
        });

        
        wrapper.destroy = function () {
            this.top.destroy();
            this.out.destroy();
            this.inn.destroy();
            this.side1.destroy();
            this.side2.destroy();

            Highcharts.SVGElement.prototype.destroy.call(this);
        };
        
        wrapper.hide = function () {
            this.top.hide();
            this.out.hide();
            this.inn.hide();
            this.side1.hide();
            this.side2.hide();
        };
        wrapper.show = function () {
            this.top.show();
            this.out.show();
            this.inn.show();
            this.side1.show();
            this.side2.show();
        };
        return wrapper;
    };

    
    Highcharts.SVGRenderer.prototype.arc3dPath = function (shapeArgs) {
        var cx = shapeArgs.x, 
            cy = shapeArgs.y, 
            start = shapeArgs.start, 
            end = shapeArgs.end - 0.00001, 
            r = shapeArgs.r, 
            ir = shapeArgs.innerR, 
            d = shapeArgs.depth, 
            alpha = shapeArgs.alpha, 
            beta = shapeArgs.beta; 

        
        var cs = cos(start),        
            ss = sin(start),        
            ce = cos(end),            
            se = sin(end),            
            rx = r * cos(beta),        
            ry = r * cos(alpha),    
            irx = ir * cos(beta),    
            iry = ir * cos(alpha),    
            dx = d * sin(beta),       
            dy = d * sin(alpha);    

        
        var top = ['M', cx + (rx * cs), cy + (ry * ss)];
        top = top.concat(curveTo(cx, cy, rx, ry, start, end, 0, 0));
        top = top.concat([
            'L', cx + (irx * ce), cy + (iry * se)
        ]);
        top = top.concat(curveTo(cx, cy, irx, iry, end, start, 0, 0));
        top = top.concat(['Z']);
        
        var b = (beta > 0 ? PI / 2 : 0),
            a = (alpha > 0 ? 0 : PI / 2);

        var start2 = start > -b ? start : (end > -b ? -b : start),
            end2 = end < PI - a ? end : (start < PI - a ? PI - a : end),
            midEnd = 2 * PI - a;
    

        var out = ['M', cx + (rx * cos(start2)), cy + (ry * sin(start2))];
        out = out.concat(curveTo(cx, cy, rx, ry, start2, end2, 0, 0));

        if (end > midEnd && start < midEnd) { 
            out = out.concat([
                'L', cx + (rx * cos(end2)) + dx, cy + (ry * sin(end2)) + dy
            ]);
            
            out = out.concat(curveTo(cx, cy, rx, ry, end2, midEnd, dx, dy));
            
            out = out.concat([
                'L', cx + (rx * cos(midEnd)), cy + (ry * sin(midEnd))
            ]);
            
            out = out.concat(curveTo(cx, cy, rx, ry, midEnd, end, 0, 0));
            
            out = out.concat([
                'L', cx + (rx * cos(end)) + dx, cy + (ry * sin(end)) + dy
            ]);
            
            out = out.concat(curveTo(cx, cy, rx, ry, end, midEnd, dx, dy));
            out = out.concat([
                'L', cx + (rx * cos(midEnd)), cy + (ry * sin(midEnd))
            ]);
            
            out = out.concat(curveTo(cx, cy, rx, ry, midEnd, end2, 0, 0));
        } else if (end > PI - a && start < PI - a) { 
            out = out.concat([
                'L', cx + (rx * cos(end2)) + dx, cy + (ry * sin(end2)) + dy
            ]);
           
            out = out.concat(curveTo(cx, cy, rx, ry, end2, end, dx, dy));
           
            out = out.concat([
                'L', cx + (rx * cos(end)), cy + (ry * sin(end))
            ]);
            
            out = out.concat(curveTo(cx, cy, rx, ry, end, end2, 0, 0));
        }

        out = out.concat([
            'L', cx + (rx * cos(end2)) + dx, cy + (ry * sin(end2)) + dy
        ]);
        out = out.concat(curveTo(cx, cy, rx, ry, end2, start2, dx, dy));
        out = out.concat(['Z']);

        
        var inn = ['M', cx + (irx * cs), cy + (iry * ss)];
        inn = inn.concat(curveTo(cx, cy, irx, iry, start, end, 0, 0));
        inn = inn.concat([
            'L', cx + (irx * cos(end)) + dx, cy + (iry * sin(end)) + dy
        ]);
        inn = inn.concat(curveTo(cx, cy, irx, iry, end, start, dx, dy));
        inn = inn.concat(['Z']);

        
        var side1 = [
            'M', cx + (rx * cs), cy + (ry * ss),
            'L', cx + (rx * cs) + dx, cy + (ry * ss) + dy,
            'L', cx + (irx * cs) + dx, cy + (iry * ss) + dy,
            'L', cx + (irx * cs), cy + (iry * ss),
            'Z'
        ];
        var side2 = [
            'M', cx + (rx * ce), cy + (ry * se),
            'L', cx + (rx * ce) + dx, cy + (ry * se) + dy,
            'L', cx + (irx * ce) + dx, cy + (iry * se) + dy,
            'L', cx + (irx * ce), cy + (iry * se),
            'Z'
        ];

        
        var angleCorr = Math.atan2(dy, -dx),
            angleEnd = Math.abs(end + angleCorr),
            angleStart = Math.abs(start + angleCorr),
            angleMid = Math.abs((start + end) / 2 + angleCorr);

        
        function toZeroPIRange(angle) {
            angle = angle % (2 * PI);
            if (angle > PI) {
                angle = 2 * PI - angle;
            }
            return angle;
        }
        angleEnd = toZeroPIRange(angleEnd);
        angleStart = toZeroPIRange(angleStart);
        angleMid = toZeroPIRange(angleMid);

        
        var incPrecision = 1e5,
            a1 = angleMid * incPrecision,
            a2 = angleStart * incPrecision,
            a3 = angleEnd * incPrecision;

        return {
            top: top,
            zTop: PI * incPrecision + 1, 
            out: out,
            zOut: Math.max(a1, a2, a3),
            inn: inn,
            zInn: Math.max(a1, a2, a3),
            side1: side1,
            zSide1: a3 * 0.99, 
            side2: side2,
            zSide2: a2 * 0.99
        };
    };
    
    Highcharts.Chart.prototype.is3d = function () {
        return this.options.chart.options3d && this.options.chart.options3d.enabled; // #4280
    };

    Highcharts.wrap(Highcharts.Chart.prototype, 'isInsidePlot', function (proceed) {
        return this.is3d() || proceed.apply(this, [].slice.call(arguments, 1));
    });

    var defaultChartOptions = Highcharts.getOptions();
    defaultChartOptions.chart.options3d = {
        enabled: false,
        alpha: 0,
        beta: 0,
        depth: 100,
        viewDistance: 25,
        frame: {
            bottom: { size: 1, color: 'rgba(255,255,255,0)' },
            side: { size: 1, color: 'rgba(255,255,255,0)' },
            back: { size: 1, color: 'rgba(255,255,255,0)' }
        }
    };

    Highcharts.wrap(Highcharts.Chart.prototype, 'init', function (proceed) {
        var args = [].slice.call(arguments, 1),
            plotOptions,
            pieOptions;

        if (args[0].chart && args[0].chart.options3d && args[0].chart.options3d.enabled) {
            
            args[0].chart.options3d.alpha = (args[0].chart.options3d.alpha || 0) % 360;
            args[0].chart.options3d.beta = (args[0].chart.options3d.beta || 0) % 360;

            plotOptions = args[0].plotOptions || {};
            pieOptions = plotOptions.pie || {};

            pieOptions.borderColor = Highcharts.pick(pieOptions.borderColor, undefined);
        }
        proceed.apply(this, args);
    });

    Highcharts.wrap(Highcharts.Chart.prototype, 'setChartSize', function (proceed) {
        proceed.apply(this, [].slice.call(arguments, 1));

        if (this.is3d()) {
            var inverted = this.inverted,
                clipBox = this.clipBox,
                margin = this.margin,
                x = inverted ? 'y' : 'x',
                y = inverted ? 'x' : 'y',
                w = inverted ? 'height' : 'width',
                h = inverted ? 'width' : 'height';

            clipBox[x] = -(margin[3] || 0);
            clipBox[y] = -(margin[0] || 0);
            clipBox[w] = this.chartWidth + (margin[3] || 0) + (margin[1] || 0);
            clipBox[h] = this.chartHeight + (margin[0] || 0) + (margin[2] || 0);
        }
    });

    Highcharts.wrap(Highcharts.Chart.prototype, 'redraw', function (proceed) {
        if (this.is3d()) {
            
            this.isDirtyBox = true;
        }
        proceed.apply(this, [].slice.call(arguments, 1));
    });

    
    Highcharts.wrap(Highcharts.Chart.prototype, 'renderSeries', function (proceed) {
        var series,
            i = this.series.length;

        if (this.is3d()) {
            while (i--) {
                series = this.series[i];
                series.translate();
                series.render();
            }
        } else {
            proceed.call(this);
        }
    });

    Highcharts.Chart.prototype.retrieveStacks = function (stacking) {
        var series = this.series,
            stacks = {},
            stackNumber,
            i = 1;

        Highcharts.each(this.series, function (s) {
            stackNumber = pick(s.options.stack, (stacking ? 0 : series.length - 1 - s.index)); 
            if (!stacks[stackNumber]) {
                stacks[stackNumber] = { series: [s], position: i };
                i++;
            } else {
                stacks[stackNumber].series.push(s);
            }
        });

        stacks.totalStacks = i + 1;
        return stacks;
    };

   
    Highcharts.wrap(Highcharts.Axis.prototype, 'setOptions', function (proceed, userOptions) {
        var options;
        proceed.call(this, userOptions);
        if (this.chart.is3d()) {
            options = this.options;
            options.tickWidth = Highcharts.pick(options.tickWidth, 0);
            options.gridLineWidth = Highcharts.pick(options.gridLineWidth, 1);
        }
    });

    Highcharts.wrap(Highcharts.Axis.prototype, 'render', function (proceed) {
        proceed.apply(this, [].slice.call(arguments, 1));

        
        if (!this.chart.is3d()) {
            return;
        }

        var chart = this.chart,
            renderer = chart.renderer,
            options3d = chart.options.chart.options3d,
            frame = options3d.frame,
            fbottom = frame.bottom,
            fback = frame.back,
            fside = frame.side,
            depth = options3d.depth,
            height = this.height,
            width = this.width,
            left = this.left,
            top = this.top;

        if (this.isZAxis) {
            return;
        }
        if (this.horiz) {
            var bottomShape = {
                x: left,
                y: top + (chart.xAxis[0].opposite ? -fbottom.size : height),
                z: 0,
                width: width,
                height: fbottom.size,
                depth: depth,
                insidePlotArea: false
            };
            if (!this.bottomFrame) {
                this.bottomFrame = renderer.cuboid(bottomShape).attr({
                    fill: fbottom.color,
                    zIndex: (chart.yAxis[0].reversed && options3d.alpha > 0 ? 4 : -1)
                })
                .css({
                    stroke: fbottom.color
                }).add();
            } else {
                this.bottomFrame.animate(bottomShape);
            }
        } else {
            
            var backShape = {
                x: left + (chart.yAxis[0].opposite ? 0 : -fside.size),
                y: top + (chart.xAxis[0].opposite ? -fbottom.size : 0),
                z: depth,
                width: width + fside.size,
                height: height + fbottom.size,
                depth: fback.size,
                insidePlotArea: false
            };
            if (!this.backFrame) {
                this.backFrame = renderer.cuboid(backShape).attr({
                    fill: fback.color,
                    zIndex: -3
                }).css({
                    stroke: fback.color
                }).add();
            } else {
                this.backFrame.animate(backShape);
            }
            var sideShape = {
                x: left + (chart.yAxis[0].opposite ? width : -fside.size),
                y: top + (chart.xAxis[0].opposite ? -fbottom.size : 0),
                z: 0,
                width: fside.size,
                height: height + fbottom.size,
                depth: depth,
                insidePlotArea: false
            };
            if (!this.sideFrame) {
                this.sideFrame = renderer.cuboid(sideShape).attr({
                    fill: fside.color,
                    zIndex: -2
                }).css({
                    stroke: fside.color
                }).add();
            } else {
                this.sideFrame.animate(sideShape);
            }
        }
    });

    Highcharts.wrap(Highcharts.Axis.prototype, 'getPlotLinePath', function (proceed) {
        var path = proceed.apply(this, [].slice.call(arguments, 1));

        
        if (!this.chart.is3d()) {
            return path;
        }

        if (path === null) {
            return path;
        }

        var chart = this.chart,
            options3d = chart.options.chart.options3d,
            d = this.isZAxis ? chart.plotWidth : options3d.depth,
            opposite = this.opposite;
        if (this.horiz) {
            opposite = !opposite;
        }
        var pArr = [
            this.swapZ({ x: path[1], y: path[2], z: (opposite ? d : 0) }),
            this.swapZ({ x: path[1], y: path[2], z: d }),
            this.swapZ({ x: path[4], y: path[5], z: d }),
            this.swapZ({ x: path[4], y: path[5], z: (opposite ? 0 : d) })
        ];

        pArr = perspective(pArr, this.chart, false);
        path = this.chart.renderer.toLinePath(pArr, false);

        return path;
    });

   
    Highcharts.wrap(Highcharts.Axis.prototype, 'getLinePath', function (proceed) {
        return this.chart.is3d() ? [] : proceed.apply(this, [].slice.call(arguments, 1));
    });

    Highcharts.wrap(Highcharts.Axis.prototype, 'getPlotBandPath', function (proceed) {
        
        if (!this.chart.is3d()) {
            return proceed.apply(this, [].slice.call(arguments, 1));
        }

        var args = arguments,
            from = args[1],
            to = args[2],
            toPath = this.getPlotLinePath(to),
            path = this.getPlotLinePath(from);

        if (path && toPath) {
            path.push(
                'L',
                toPath[10],   
                toPath[11],  
                'L',
                toPath[7],
                toPath[8],
                'L',
                toPath[4],
                toPath[5],
                'L',
                toPath[1],
                toPath[2]
            );
        } else { 
            path = null;
        }

        return path;
    });

    

    Highcharts.wrap(Highcharts.Tick.prototype, 'getMarkPath', function (proceed) {
        var path = proceed.apply(this, [].slice.call(arguments, 1));

        
        if (!this.axis.chart.is3d()) {
            return path;
        }

        var pArr = [
            this.axis.swapZ({ x: path[1], y: path[2], z: 0 }),
            this.axis.swapZ({ x: path[4], y: path[5], z: 0 })
        ];

        pArr = perspective(pArr, this.axis.chart, false);
        path = [
            'M', pArr[0].x, pArr[0].y,
            'L', pArr[1].x, pArr[1].y
        ];
        return path;
    });

    Highcharts.wrap(Highcharts.Tick.prototype, 'getLabelPosition', function (proceed) {
        var pos = proceed.apply(this, [].slice.call(arguments, 1));

        
        if (!this.axis.chart.is3d()) {
            return pos;
        }

        var newPos = perspective([this.axis.swapZ({ x: pos.x, y: pos.y, z: 0 })], this.axis.chart, false)[0];
        newPos.x = newPos.x - (!this.axis.horiz && this.axis.opposite ? this.axis.transA : 0); //#3788
        newPos.old = pos;
        return newPos;
    });

    Highcharts.wrap(Highcharts.Tick.prototype, 'handleOverflow', function (proceed, xy) {
        if (this.axis.chart.is3d()) {
            xy = xy.old;
        }
        return proceed.call(this, xy);
    });

    Highcharts.wrap(Highcharts.Axis.prototype, 'getTitlePosition', function (proceed) {
        var is3d = this.chart.is3d(),
            pos,
            axisTitleMargin;

        
        if (is3d) {
            axisTitleMargin = this.axisTitleMargin;
            this.axisTitleMargin = 0;
        }

        pos = proceed.apply(this, [].slice.call(arguments, 1));

        if (is3d) {
            pos = perspective([this.swapZ({ x: pos.x, y: pos.y, z: 0 })], this.chart, false)[0];

            
            pos[this.horiz ? 'y' : 'x'] += (this.horiz ? 1 : -1) * 
                (this.opposite ? -1 : 1) * 
                axisTitleMargin;
            this.axisTitleMargin = axisTitleMargin;
        }
        return pos;
    });

    Highcharts.wrap(Highcharts.Axis.prototype, 'drawCrosshair', function (proceed) {
        var args = arguments;
        if (this.chart.is3d()) {
            if (args[2]) {
                args[2] = {
                    plotX: args[2].plotXold || args[2].plotX,
                    plotY: args[2].plotYold || args[2].plotY
                };
            }
        }
        proceed.apply(this, [].slice.call(args, 1));
    });

    

    Highcharts.Axis.prototype.swapZ = function (p, insidePlotArea) {
        if (this.isZAxis) {
            var plotLeft = insidePlotArea ? 0 : this.chart.plotLeft;
            var chart = this.chart;
            return {
                x: plotLeft + (chart.yAxis[0].opposite ? p.z : chart.xAxis[0].width - p.z),
                y: p.y,
                z: p.x - plotLeft
            };
        }
        return p;
    };

    var ZAxis = Highcharts.ZAxis = function () {
        this.isZAxis = true;
        this.init.apply(this, arguments);
    };
    Highcharts.extend(ZAxis.prototype, Highcharts.Axis.prototype);
    Highcharts.extend(ZAxis.prototype, {
        setOptions: function (userOptions) {
            userOptions = Highcharts.merge({
                offset: 0,
                lineWidth: 0
            }, userOptions);
            Highcharts.Axis.prototype.setOptions.call(this, userOptions);
            this.coll = 'zAxis';
        },
        setAxisSize: function () {
            Highcharts.Axis.prototype.setAxisSize.call(this);
            this.width = this.len = this.chart.options.chart.options3d.depth;
            this.right = this.chart.chartWidth - this.width - this.left;
        },
        getSeriesExtremes: function () {
            var axis = this,
                chart = axis.chart;

            axis.hasVisibleSeries = false;

            
            axis.dataMin = axis.dataMax = axis.ignoreMinPadding = axis.ignoreMaxPadding = null;

            if (axis.buildStacks) {
                axis.buildStacks();
            }

            
            Highcharts.each(axis.series, function (series) {

                if (series.visible || !chart.options.chart.ignoreHiddenSeries) {

                    var seriesOptions = series.options,
                        zData,
                        threshold = seriesOptions.threshold;

                    axis.hasVisibleSeries = true;

                    
                    if (axis.isLog && threshold <= 0) {
                        threshold = null;
                    }

                    zData = series.zData;
                    if (zData.length) {
                        axis.dataMin = Math.min(pick(axis.dataMin, zData[0]), Math.min.apply(null, zData));
                        axis.dataMax = Math.max(pick(axis.dataMax, zData[0]), Math.max.apply(null, zData));
                    }
                }
            });
        }
    });


    
    Highcharts.wrap(Highcharts.Chart.prototype, 'getAxes', function (proceed) {
        var chart = this,
            options = this.options,
            zAxisOptions = options.zAxis = Highcharts.splat(options.zAxis || {});

        proceed.call(this);

        if (!chart.is3d()) {
            return;
        }
        this.zAxis = [];
        Highcharts.each(zAxisOptions, function (axisOptions, i) {
            axisOptions.index = i;
            axisOptions.isX = true; 
            var zAxis = new ZAxis(chart, axisOptions);
            zAxis.setScale();
        });
    });
    
    Highcharts.wrap(Highcharts.seriesTypes.column.prototype, 'translate', function (proceed) {
        proceed.apply(this, [].slice.call(arguments, 1));

        
        if (!this.chart.is3d()) {
            return;
        }

        var series = this,
            chart = series.chart,
            seriesOptions = series.options,
            depth = seriesOptions.depth || 25;

        var stack = seriesOptions.stacking ? (seriesOptions.stack || 0) : series._i;
        var z = stack * (depth + (seriesOptions.groupZPadding || 1));

        if (seriesOptions.grouping !== false) {
            z = 0;
        }

        z += (seriesOptions.groupZPadding || 1);

        Highcharts.each(series.data, function (point) {
            if (point.y !== null) {
                var shapeArgs = point.shapeArgs,
                    tooltipPos = point.tooltipPos;

                point.shapeType = 'cuboid';
                shapeArgs.z = z;
                shapeArgs.depth = depth;
                shapeArgs.insidePlotArea = true;

                
                tooltipPos = perspective([{ x: tooltipPos[0], y: tooltipPos[1], z: z }], chart, false)[0];
                point.tooltipPos = [tooltipPos.x, tooltipPos.y];
            }
        });
        
        series.z = z;
    });

    Highcharts.wrap(Highcharts.seriesTypes.column.prototype, 'animate', function (proceed) {
        if (!this.chart.is3d()) {
            proceed.apply(this, [].slice.call(arguments, 1));
        } else {
            var args = arguments,
                init = args[1],
                yAxis = this.yAxis,
                series = this,
                reversed = this.yAxis.reversed;

            if (Highcharts.svg) { 
                if (init) {
                    Highcharts.each(series.data, function (point) {
                        if (point.y !== null) {
                            point.height = point.shapeArgs.height;
                            point.shapey = point.shapeArgs.y;    
                            point.shapeArgs.height = 1;
                            if (!reversed) {
                                if (point.stackY) {
                                    point.shapeArgs.y = point.plotY + yAxis.translate(point.stackY);
                                } else {
                                    point.shapeArgs.y = point.plotY + (point.negative ? -point.height : point.height);
                                }
                            }
                        }
                    });

                } else { 
                    Highcharts.each(series.data, function (point) {
                        if (point.y !== null) {
                            point.shapeArgs.height = point.height;
                            point.shapeArgs.y = point.shapey;    
                            
                            if (point.graphic) {
                                point.graphic.animate(point.shapeArgs, series.options.animation);
                            }
                        }
                    });

                    
                    this.drawDataLabels();

                    
                    series.animate = null;
                }
            }
        }
    });

    Highcharts.wrap(Highcharts.seriesTypes.column.prototype, 'init', function (proceed) {
        proceed.apply(this, [].slice.call(arguments, 1));

        if (this.chart.is3d()) {
            var seriesOptions = this.options,
                grouping = seriesOptions.grouping,
                stacking = seriesOptions.stacking,
                reversedStacks = pick(this.yAxis.options.reversedStacks, true),
                z = 0;
        
            if (!(grouping !== undefined && !grouping)) {
                var stacks = this.chart.retrieveStacks(stacking),
                    stack = seriesOptions.stack || 0,
                    i; 
                for (i = 0; i < stacks[stack].series.length; i++) {
                    if (stacks[stack].series[i] === this) {
                        break;
                    }
                }
                z = (10 * (stacks.totalStacks - stacks[stack].position)) + (reversedStacks ? i : -i); 

                
                if (!this.xAxis.reversed) {
                    z = (stacks.totalStacks * 10) - z;
                }
            }

            seriesOptions.zIndex = z;
        }
    });
    function draw3DPoints(proceed) {
        
        if (this.chart.is3d()) {
            var grouping = this.chart.options.plotOptions.column.grouping;
            if (grouping !== undefined && !grouping && this.group.zIndex !== undefined && !this.zIndexSet) {
                this.group.attr({ zIndex: this.group.zIndex * 10 });
                this.zIndexSet = true; 
            }

            var options = this.options,
                states = this.options.states;

            this.borderWidth = options.borderWidth = defined(options.edgeWidth) ? options.edgeWidth : 1; 

            Highcharts.each(this.data, function (point) {
                if (point.y !== null) {
                    var pointAttr = point.pointAttr;

                    
                    this.borderColor = Highcharts.pick(options.edgeColor, pointAttr[''].fill);

                    pointAttr[''].stroke = this.borderColor;
                    pointAttr.hover.stroke = Highcharts.pick(states.hover.edgeColor, this.borderColor);
                    pointAttr.select.stroke = Highcharts.pick(states.select.edgeColor, this.borderColor);
                }
            });
        }

        proceed.apply(this, [].slice.call(arguments, 1));
    }

    Highcharts.wrap(Highcharts.Series.prototype, 'alignDataLabel', function (proceed) {

        
        if (this.chart.is3d() && (this.type === 'column' || this.type === 'columnrange')) {
            var series = this,
                chart = series.chart;

            var args = arguments,
                alignTo = args[4];

            var pos = ({ x: alignTo.x, y: alignTo.y, z: series.z });
            pos = perspective([pos], chart, true)[0];
            alignTo.x = pos.x;
            alignTo.y = pos.y;
        }

        proceed.apply(this, [].slice.call(arguments, 1));
    });

    if (Highcharts.seriesTypes.columnrange) {
        Highcharts.wrap(Highcharts.seriesTypes.columnrange.prototype, 'drawPoints', draw3DPoints);
    }

    Highcharts.wrap(Highcharts.seriesTypes.column.prototype, 'drawPoints', draw3DPoints);

    

    Highcharts.wrap(Highcharts.seriesTypes.pie.prototype, 'translate', function (proceed) {
        proceed.apply(this, [].slice.call(arguments, 1));

        
        if (!this.chart.is3d()) {
            return;
        }

        var series = this,
            chart = series.chart,
            options = chart.options,
            seriesOptions = series.options,
            depth = seriesOptions.depth || 0,
            options3d = options.chart.options3d,
            alpha = options3d.alpha,
            beta = options3d.beta,
            z = seriesOptions.stacking ? (seriesOptions.stack || 0) * depth : series._i * depth;

        z += depth / 2;

        if (seriesOptions.grouping !== false) {
            z = 0;
        }

        each(series.data, function (point) {

            var shapeArgs = point.shapeArgs,
                angle;

            point.shapeType = 'arc3d';

            shapeArgs.z = z;
            shapeArgs.depth = depth * 0.75;
            shapeArgs.alpha = alpha;
            shapeArgs.beta = beta;
            shapeArgs.center = series.center;

            angle = (shapeArgs.end + shapeArgs.start) / 2;

            point.slicedTranslation = {
                translateX: round(cos(angle) * seriesOptions.slicedOffset * cos(alpha * deg2rad)),
                translateY: round(sin(angle) * seriesOptions.slicedOffset * cos(alpha * deg2rad))
            };
        });
    });

    Highcharts.wrap(Highcharts.seriesTypes.pie.prototype.pointClass.prototype, 'haloPath', function (proceed) {
        var args = arguments;
        return this.series.chart.is3d() ? [] : proceed.call(this, args[1]);
    });

    Highcharts.wrap(Highcharts.seriesTypes.pie.prototype, 'drawPoints', function (proceed) {

        var options = this.options,
            states = options.states;

        
        if (this.chart.is3d()) {
            
            this.borderWidth = options.borderWidth = options.edgeWidth || 1;
            this.borderColor = options.edgeColor = Highcharts.pick(options.edgeColor, options.borderColor, undefined);

            states.hover.borderColor = Highcharts.pick(states.hover.edgeColor, this.borderColor);
            states.hover.borderWidth = Highcharts.pick(states.hover.edgeWidth, this.borderWidth);
            states.select.borderColor = Highcharts.pick(states.select.edgeColor, this.borderColor);
            states.select.borderWidth = Highcharts.pick(states.select.edgeWidth, this.borderWidth);

            each(this.data, function (point) {
                var pointAttr = point.pointAttr;
                pointAttr[''].stroke = point.series.borderColor || point.color;
                pointAttr['']['stroke-width'] = point.series.borderWidth;
                pointAttr.hover.stroke = states.hover.borderColor;
                pointAttr.hover['stroke-width'] = states.hover.borderWidth;
                pointAttr.select.stroke = states.select.borderColor;
                pointAttr.select['stroke-width'] = states.select.borderWidth;
            });
        }

        proceed.apply(this, [].slice.call(arguments, 1));

        if (this.chart.is3d()) {
            each(this.points, function (point) {
                var graphic = point.graphic;

                
                if (graphic) {
                    
                    graphic[point.y ? 'show' : 'hide']();
                }
            });    
        }
    });

    Highcharts.wrap(Highcharts.seriesTypes.pie.prototype, 'drawDataLabels', function (proceed) {
        if (this.chart.is3d()) {
            var series = this,
                chart = series.chart,
                options3d = chart.options.chart.options3d;
            each(series.data, function (point) {
                var shapeArgs = point.shapeArgs,
                    r = shapeArgs.r,
                    a1 = (shapeArgs.alpha || options3d.alpha) * deg2rad, 
                    b1 = (shapeArgs.beta || options3d.beta) * deg2rad,
                    a2 = (shapeArgs.start + shapeArgs.end) / 2,
                    labelPos = point.labelPos,
                    labelIndexes = [0, 2, 4], 
                    yOffset = (-r * (1 - cos(a1)) * sin(a2)), 
                    xOffset = r * (cos(b1) - 1) * cos(a2);

                
                each(labelIndexes, function (index) {
                    labelPos[index] += xOffset;
                    labelPos[index + 1] += yOffset;
                });
            });
        }

        proceed.apply(this, [].slice.call(arguments, 1));
    });

    Highcharts.wrap(Highcharts.seriesTypes.pie.prototype, 'addPoint', function (proceed) {
        proceed.apply(this, [].slice.call(arguments, 1));
        if (this.chart.is3d()) {
            
            this.update(this.userOptions, true); 
        }
    });

    Highcharts.wrap(Highcharts.seriesTypes.pie.prototype, 'animate', function (proceed) {
        if (!this.chart.is3d()) {
            proceed.apply(this, [].slice.call(arguments, 1));
        } else {
            var args = arguments,
                init = args[1],
                animation = this.options.animation,
                attribs,
                center = this.center,
                group = this.group,
                markerGroup = this.markerGroup;

            if (Highcharts.svg) { 

                if (animation === true) {
                    animation = {};
                }
                
                if (init) {

                    
                    group.oldtranslateX = group.translateX;
                    group.oldtranslateY = group.translateY;
                    attribs = {
                        translateX: center[0],
                        translateY: center[1],
                        scaleX: 0.001, 
                        scaleY: 0.001
                    };

                    group.attr(attribs);
                    if (markerGroup) {
                        markerGroup.attrSetters = group.attrSetters;
                        markerGroup.attr(attribs);
                    }

                
                } else {
                    attribs = {
                        translateX: group.oldtranslateX,
                        translateY: group.oldtranslateY,
                        scaleX: 1,
                        scaleY: 1
                    };
                    group.animate(attribs, animation);

                    if (markerGroup) {
                        markerGroup.animate(attribs, animation);
                    }

                    
                    this.animate = null;
                }

            }
        }
    });
    

    Highcharts.wrap(Highcharts.seriesTypes.scatter.prototype, 'translate', function (proceed) {
   
        proceed.apply(this, [].slice.call(arguments, 1));

        if (!this.chart.is3d()) {
            return;
        }

        var series = this,
            chart = series.chart,
            zAxis = Highcharts.pick(series.zAxis, chart.options.zAxis[0]),
            rawPoints = [],
            rawPoint,
            projectedPoints,
            projectedPoint,
            zValue,
            i;

        for (i = 0; i < series.data.length; i++) {
            rawPoint = series.data[i];
            zValue = zAxis.isLog && zAxis.val2lin ? zAxis.val2lin(rawPoint.z) : rawPoint.z; 
            rawPoint.plotZ = zAxis.translate(zValue);

            rawPoint.isInside = rawPoint.isInside ? (zValue >= zAxis.min && zValue <= zAxis.max) : false;

            rawPoints.push({
                x: rawPoint.plotX,
                y: rawPoint.plotY,
                z: rawPoint.plotZ
            });
        }

        projectedPoints = perspective(rawPoints, chart, true);

        for (i = 0; i < series.data.length; i++) {
            rawPoint = series.data[i];
            projectedPoint = projectedPoints[i];

            rawPoint.plotXold = rawPoint.plotX;
            rawPoint.plotYold = rawPoint.plotY;

            rawPoint.plotX = projectedPoint.x;
            rawPoint.plotY = projectedPoint.y;
            rawPoint.plotZ = projectedPoint.z;


        }

    });

    Highcharts.wrap(Highcharts.seriesTypes.scatter.prototype, 'init', function (proceed, chart, options) {
        if (chart.is3d()) {
            
            this.axisTypes = ['xAxis', 'yAxis', 'zAxis'];
            this.pointArrayMap = ['x', 'y', 'z'];
            this.parallelArrays = ['x', 'y', 'z'];
        }

        var result = proceed.apply(this, [chart, options]);

        if (this.chart.is3d()) {
            
            var default3dScatterTooltip = 'x: <b>{point.x}</b><br/>y: <b>{point.y}</b><br/>z: <b>{point.z}</b><br/>';
            if (this.userOptions.tooltip) {
                this.tooltipOptions.pointFormat = this.userOptions.tooltip.pointFormat || default3dScatterTooltip;
            } else {
                this.tooltipOptions.pointFormat = default3dScatterTooltip;
            }
        }
        return result;
    });
   
    if (Highcharts.VMLRenderer) {

        Highcharts.setOptions({ animate: false });

        Highcharts.VMLRenderer.prototype.cuboid = Highcharts.SVGRenderer.prototype.cuboid;
        Highcharts.VMLRenderer.prototype.cuboidPath = Highcharts.SVGRenderer.prototype.cuboidPath;

        Highcharts.VMLRenderer.prototype.toLinePath = Highcharts.SVGRenderer.prototype.toLinePath;

        Highcharts.VMLRenderer.prototype.createElement3D = Highcharts.SVGRenderer.prototype.createElement3D;

        Highcharts.VMLRenderer.prototype.arc3d = function (shapeArgs) {
            var result = Highcharts.SVGRenderer.prototype.arc3d.call(this, shapeArgs);
            result.css({ zIndex: result.zIndex });
            return result;
        };

        Highcharts.VMLRenderer.prototype.arc3dPath = Highcharts.SVGRenderer.prototype.arc3dPath;

        Highcharts.wrap(Highcharts.Axis.prototype, 'render', function (proceed) {
            proceed.apply(this, [].slice.call(arguments, 1));
          
            if (this.sideFrame) {
                this.sideFrame.css({ zIndex: 0 });
                this.sideFrame.front.attr({ fill: this.sideFrame.color });
            }
            if (this.bottomFrame) {
                this.bottomFrame.css({ zIndex: 1 });
                this.bottomFrame.front.attr({ fill: this.bottomFrame.color });
            }
            if (this.backFrame) {
                this.backFrame.css({ zIndex: 0 });
                this.backFrame.front.attr({ fill: this.backFrame.color });
            }
        });

    }

}));
